const { ethers, upgrades } = require("hardhat");

async function main() {
  const MetaLicensePlates = await ethers.getContractFactory("MetaLicensePlates");
  //token name, token symbol, mint price, max supply,  qty per wallet,revenue share percentage 2%, royalty owner, url
  const metaLicensePlates = await upgrades.deployProxy(MetaLicensePlates, 
    ["MLP_Name", "MLP",
     100, 5000, 5, 
     "0xdC965981B5C30da2d13D23Ff4B8f9dC6a775c735", 
     "https://raw.githubusercontent.com/crissi/acc_ref/main/",
     200, 
     300,
     "0x78b10c0791b87c9Df107E6Ace0Ae00CCE4407f45"
    ], {
    initializer:"initialize",
  });
await metaLicensePlates.deployed();

  console.log("MetaLicensePlates deployed to:", metaLicensePlates.address);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
